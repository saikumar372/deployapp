import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AdminDashboardComponent } from '../admin-dashboard/admin-dashboard.component';
import { AdminUserListingComponent } from '../admin-user-listing/admin-user-listing.component';


const routes: Routes = [
  {
    path:'',
    redirectTo: 'login'
  },{
  path:'',
  component:AdminComponent,
  children:[
    {
      path:'',
      redirectTo: 'login'
    },
    {
      path:'dashboard',
      component:AdminDashboardComponent
    },
    {
      path:'user',
      component:AdminUserListingComponent
    },
]

},
{
  path:'login',
  loadChildren: () => import('../login-outlet/login-outlet.module').then(m => m.LoginOutletModule)
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
