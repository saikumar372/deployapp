import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css',
  '../../assets/css/admin-login.css',
  '../../assets/css/util.css'
]
})
export class AdminLoginComponent implements OnInit {

  myform:FormGroup;
  submitted = false;
  
  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
    // this.myform =this.fb.group({
    //   'username':['',Validators.required],
    //   'password':['',Validators.required]
    // });
  }
  onSubmit(){
    alert(1)
  }

}
