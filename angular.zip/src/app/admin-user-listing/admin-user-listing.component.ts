import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-user-listing',
  templateUrl: './admin-user-listing.component.html',
  styleUrls: ['./admin-user-listing.component.css']
})
export class AdminUserListingComponent implements OnInit {

  user_data :any;
  constructor() { }

  ngOnInit(): void {
    this.user_data =JSON.parse(localStorage.getItem('user'))
  }

}
