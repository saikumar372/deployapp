import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-members-detail-view',
  templateUrl: './members-detail-view.component.html',
  styleUrls: ['./members-detail-view.component.css']
})
export class MembersDetailViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
