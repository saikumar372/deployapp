import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginOutletRoutingModule } from './login-outlet-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LoginOutletRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class LoginOutletModule { }
